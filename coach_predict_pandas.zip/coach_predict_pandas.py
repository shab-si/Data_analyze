from sklearn.linear_model import LinearRegression
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
#from jdatetime import datetime as jdatetime
#from datetime import datetime
#from khayyam import JalaliDatetime
from jdatetime import datetime as jdatetime

df = pd.read_excel('coach_daramad.xlsx')
df['mah'] = df['mah'] + "/01"
print(df.to_string()) 
xx = input()
# مرتب‌سازی دیتافریم بر اساس سال و ماه
df.sort_values(by=['mah', 'coach'], inplace=True)

X = df[['sporter_pay']]  
y = df['sporter_count'] 

model = LinearRegression()
model.fit(X, y)


print('zarib Hambastegi: ', model.coef_)
print('arz az mabda: ', model.intercept_)

#plt.plot(X, model)
# رسم نمودار
plt.scatter(df['sporter_pay'], df['sporter_count'])
plt.xlabel('sporter_pay zarib (100,000,000)')
plt.ylabel('sporter_count')
plt.title('Relation of pay and count')
plt.show()

#print(df[df['sporter_count'] > 150])
print("------------------------------------------")
#df = pd.read_excel('coach_daramad.xlsx')
df = df[df['coach'] == "طاهره پيربازاري"] #"مهشيد آذري"]
print(df)
xx = input()

X = df[['sporter_pay']]  
y = df['sporter_count'] 

model = LinearRegression()
model.fit(X, y)


print('zarib Hambastegi: ', model.coef_)
print('arz az mabda: ', model.intercept_)

#plt.plot(X, model)
# رسم نمودار
plt.scatter(df['sporter_pay'], df['sporter_count'])
plt.xlabel('sporter_pay zarib (100,000,000)')
plt.ylabel('sporter_count')
plt.title('Relation of pay and count')
plt.show()

# تبدیل ستون سال ماه به تاریخ هجری شمسی
print("================")

df[['sal', 'mahjoda', 'rooz']] = df['mah'].str.split("/", expand=True)
df = df.astype({'sal':'int'})
df = df.astype({'mahjoda':'int'})
df = df.astype({'rooz':'int'})
print(df)
xx = input()
print("======================================")

def to_jalali(row):
   return jdatetime(int(row['sal']), int(row['mahjoda']), int(row['rooz']))


def to_gregorian(row):
   jalali_date = jdatetime(int(row['sal']), int(row['mahjoda']), int(row['rooz']))
   gregorian_date = jalali_date.togregorian()
   return gregorian_date
   
def predict_next_month(row):
   next_month = (row['miladiMonth'] % 12) + 1
   next_year = row['miladiYear'] + 1 if next_month == 1 else row['miladiYear']
   next_month_df = df[(df['coach'] == row['coach']) & (df['miladiMonth'] == next_month) & (df['miladiYear'] == next_year)]
   if not next_month_df.empty:
     return next_month_df.iloc[0]['sporter_count']
   else:
     return None
   

df['TarikhShamsi'] = df.apply(to_jalali,  axis = 1)
df['TarikhMiladi'] = df.apply(to_gregorian, axis=1)
df['miladiMonth'] = pd.to_datetime(df['TarikhMiladi']).dt.month
df['miladiYear'] = pd.to_datetime(df['TarikhMiladi']).dt.year

df['sporter_count_Next_Month'] = df.apply(predict_next_month, axis=1)
print(df)
xx = input()
print("=======================")
df_copy = df.copy()
#از اینجا به بعد به ستونهایی که نیاز داریم، آورده بشند
df_copy = df_copy[['coach', 'mah', 'sporter_count','sporter_pay', 'TarikhMiladi', 'sporter_count_Next_Month']]
print(df_copy)
# حذف ردیف‌هایی که پیش‌بینی نشده‌اند
df_copy.dropna(subset=['sporter_count_Next_Month'], inplace=True)
print("=========after delete not predict==============")
print(df_copy)
# آماده‌سازی داده‌ها برای مدل رگرسیون خطی برای هر مربی
models = {}
for coach in df_copy['coach'].unique():
    coach_data = df_copy[df_copy['coach'] == coach]
    if len(coach_data) >= 2:  # حداقل دو نمونه داده برای هر مربی
        X_coach = coach_data[['sporter_count']]
        y_coach = coach_data['sporter_count_Next_Month']
        model = LinearRegression()
        model.fit(X_coach, y_coach)
        models[coach] = model

#print(models)
print("==========show last row of dataframe=============")
print(df_copy.iloc[-1])
print("==========show first row of dataframe=============")
print(df_copy.iloc[0])
xx = input()
# پیش‌بینی مقادیر برای هر مربی
predictions = {}
for coach, model in models.items():
    last_sportercount = df_copy[df_copy['coach'] == coach].iloc[-1]['sporter_count']
    next_month_sportercount_predicted = model.predict([[last_sportercount]])
    predictions[coach] = next_month_sportercount_predicted[0]

print("=======================")
#print(predictions)
print("=====================================")
# نمایش پیش‌بینی برای هر مربی
for coach, prediction in predictions.items():
    print(f"Predicted sportercount for next month for {coach}: {prediction}")


